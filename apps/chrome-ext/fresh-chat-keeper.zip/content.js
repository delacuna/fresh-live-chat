(function() {
  "use strict";
  function detectMode() {
    const href = window.location.href;
    if (href.includes("live_chat_replay")) return "archive";
    if (href.includes("live_chat")) return "live";
    return "none";
  }
  const id$5 = "rpg";
  const name$4 = "RPG";
  const description$4 = "ボス・エンディング・仲間の離脱・復活など";
  const keywords$4 = [
    "ラスボス",
    "裏ボス",
    "真の黒幕",
    "隠しボス",
    "ラストボス",
    "エンディング",
    "真エンド",
    "隠しエンディング",
    "バッドエンド",
    "トゥルーエンド",
    "仲間",
    "覚醒",
    "転生",
    "離脱",
    "復活"
  ];
  const context_phrases$4 = [
    "ラスボスは",
    "裏ボスは",
    "真の黒幕は",
    "隠しボスは",
    "ラストボスは",
    "エンディングは",
    "真エンドは",
    "隠しエンディングは",
    "バッドエンドは",
    "覚醒した",
    "覚醒する",
    "仲間になる",
    "仲間になった",
    "離脱した",
    "離脱する",
    "復活した",
    "復活する",
    "転生した"
  ];
  const rpg = {
    id: id$5,
    name: name$4,
    description: description$4,
    keywords: keywords$4,
    context_phrases: context_phrases$4
  };
  const id$4 = "mystery";
  const name$3 = "推理・ミステリー";
  const description$3 = "犯人・トリック・動機・アリバイなど";
  const keywords$3 = [
    "犯人",
    "真犯人",
    "共犯",
    "動機",
    "アリバイ",
    "トリック",
    "被害者",
    "真相",
    "謎"
  ];
  const context_phrases$3 = [
    "犯人は",
    "真犯人は",
    "犯人が",
    "共犯者は",
    "動機は",
    "アリバイは",
    "トリックは",
    "真相は",
    "自作自演",
    "謎が解けた",
    "犯行は",
    "実は犯人"
  ];
  const mystery = {
    id: id$4,
    name: name$3,
    description: description$3,
    keywords: keywords$3,
    context_phrases: context_phrases$3
  };
  const id$3 = "action-horror";
  const name$2 = "アクション・ホラー";
  const description$2 = "正体・生存・裏切り・脱出など";
  const keywords$2 = [
    "正体",
    "生存者",
    "脱出",
    "味方",
    "ラスボス",
    "ボス",
    "主人公",
    "生き残り"
  ];
  const context_phrases$2 = [
    "正体は",
    "実は味方",
    "実は敵",
    "生き残るのは",
    "生き残った",
    "脱出できるのは",
    "脱出した",
    "裏切るのは",
    "裏切り者は",
    "ラスボスは",
    "ボスは"
  ];
  const actionHorror = {
    id: id$3,
    name: name$2,
    description: description$2,
    keywords: keywords$2,
    context_phrases: context_phrases$2
  };
  const id$2 = "story-general";
  const name$1 = "ストーリー全般";
  const description$1 = "ジャンル問わず使えるストーリー全般のフィルタ";
  const keywords$1 = [
    "主人公",
    "ヒロイン",
    "ラスボス",
    "結末",
    "真実",
    "正体"
  ];
  const context_phrases$1 = [
    "ネタバレ注意",
    "ネタバレあり",
    "ネタバレです",
    "ネタバレ警告",
    "結末は",
    "真実は",
    "正体は",
    "覚えておいて",
    "ここ重要",
    "伏線回収",
    "実は黒幕"
  ];
  const storyGeneral = {
    id: id$2,
    name: name$1,
    description: description$1,
    keywords: keywords$1,
    context_phrases: context_phrases$1
  };
  const id$1 = "gameplay-hints";
  const name = "攻略ヒント検出";
  const description = "指示・アドバイス系コメントをAIで判定（全ジャンル共通）";
  const keywords = [];
  const context_phrases = [];
  const stage2_phrases = [
    "ほうがいい",
    "方がいい",
    "なくていい",
    "なくていいよ",
    "なくてもいい",
    "やめとけ",
    "やめておけ",
    "しとけ",
    "しておけ",
    "でいいよ",
    "見逃してる",
    "見逃した",
    "取り逃した",
    "探索甘",
    "まだいってない",
    "まだ行ってない",
    "負けイベ",
    "戦わなくていい",
    "倒さなくていい",
    "温存",
    "節約して",
    "もったいない",
    "後で使う",
    "後で必要"
  ];
  const gameplayHints = {
    id: id$1,
    name,
    description,
    keywords,
    context_phrases,
    stage2_phrases
  };
  const ALL_GENRE_TEMPLATES = [
    rpg,
    mystery,
    actionHorror,
    storyGeneral,
    gameplayHints
  ];
  function getAllGenreTemplates() {
    return ALL_GENRE_TEMPLATES;
  }
  const $schema = "../schema.json";
  const id = "ace-attorney-1";
  const title = "逆転裁判";
  const title_aliases = [
    "Phoenix Wright: Ace Attorney",
    "Phoenix Wright Ace Attorney",
    "逆転裁判1",
    "GS1"
  ];
  const progress_type = "chapter";
  const chapters = [
    {
      id: "ch1",
      number: 1,
      title: "第1話 初めての逆転",
      description: "成歩堂龍一が弁護士として初めて法廷に立つチュートリアル事件。被告人は矢張政志、被害者は高日美佳。"
    },
    {
      id: "ch2",
      number: 2,
      title: "第2話 逆転姉妹",
      description: "恩師・綾里千尋が事務所で殺される。被疑者として逮捕された霊媒師見習いの綾里真宵を成歩堂が弁護する。"
    },
    {
      id: "ch3",
      number: 3,
      title: "第3話 逆転のトノサマン",
      description: "人気特撮番組「トノサマン」の撮影スタジオで起きた殺人事件。俳優の荷星三郎を成歩堂が弁護する。"
    },
    {
      id: "ch4",
      number: 4,
      title: "第4話 逆転、そしてサヨナラ",
      description: "湖畔での殺人事件と、15年前の未解決事件「DL-6号事件」が交錯する。御剣怜侍が被告となり、成歩堂が弁護する。"
    },
    {
      id: "ch5",
      number: 5,
      title: "第5話 蘇る逆転",
      description: "（DS版追加エピソード）被告人は検事正の宝月巴。警察内部で起きた多田敷道夫の殺人事件と、2年前の未解決事件「SL-9号事件」の真相が交錯する。"
    }
  ];
  const spoiler_entities = [
    {
      id: "ch1-victim-cindy",
      name: "高日美佳",
      aliases: [
        "Cindy Stone"
      ],
      unlocked_after_chapter: "ch1",
      keywords: [
        "高日",
        "高日美佳",
        "Cindy Stone",
        "Cindy",
        "被害者"
      ],
      category: "other",
      spoiler_level: "direct_spoiler",
      description: "第1話の被害者。矢張政志の元カノ。"
    },
    {
      id: "ch1-culprit-sahwit",
      name: "山野星雄",
      aliases: [
        "Frank Sahwit",
        "山野"
      ],
      unlocked_after_chapter: "ch1",
      keywords: [
        "山野",
        "山野星雄",
        "Frank Sahwit",
        "Sahwit",
        "犯人"
      ],
      category: "plot_twist",
      spoiler_level: "direct_spoiler",
      description: "第1話の犯人。空き巣中に被害者に目撃されたため殺害した。"
    },
    {
      id: "ch1-weapon-clock",
      name: "置き時計（凶器）",
      aliases: [
        "clock",
        "the clock",
        "時計"
      ],
      unlocked_after_chapter: "ch1",
      keywords: [
        "置き時計",
        "時計",
        "凶器",
        "clock"
      ],
      category: "item_location",
      spoiler_level: "gameplay_hint",
      description: "第1話の凶器。テレビのリモコンと見誤られた点が論点になる。"
    },
    {
      id: "ch2-victim-mia",
      name: "綾里千尋（死亡）",
      aliases: [
        "Mia Fey",
        "綾里先生",
        "千尋"
      ],
      unlocked_after_chapter: "ch2",
      keywords: [
        "綾里千尋",
        "千尋",
        "Mia Fey",
        "Mia",
        "死んだ",
        "殺された",
        "被害者"
      ],
      category: "character_death",
      spoiler_level: "direct_spoiler",
      description: "成歩堂の師匠・綾里千尋が第2話冒頭で殺害される。以降は真宵の口寄せを通じて登場。"
    },
    {
      id: "ch2-culprit-redd-white",
      name: "小中大",
      aliases: [
        "Redd White",
        "ブルーコープ",
        "Bluecorp"
      ],
      unlocked_after_chapter: "ch2",
      keywords: [
        "小中",
        "小中大",
        "Redd White",
        "ブルーコープ",
        "Bluecorp",
        "犯人"
      ],
      category: "plot_twist",
      spoiler_level: "direct_spoiler",
      description: "第2話の犯人。情報を武器に各界の有力者を脅迫していた実業家。千尋の過去の調査を阻むために殺害した。"
    },
    {
      id: "ch2-maya-suspect",
      name: "綾里真宵（容疑者として誤認逮捕）",
      aliases: [
        "Maya Fey",
        "真宵",
        "Maya"
      ],
      unlocked_after_chapter: "ch2",
      keywords: [
        "綾里真宵",
        "真宵",
        "Maya Fey",
        "Maya",
        "逮捕",
        "容疑者"
      ],
      category: "plot_twist",
      spoiler_level: "foreshadowing_hint",
      description: "第2話で姉・千尋の殺人犯として誤認逮捕される。実際は無実で、成歩堂の弁護により釈放される。"
    },
    {
      id: "ch2-channeling",
      name: "口寄せ（綾里家の霊媒能力）",
      aliases: [
        "channeling",
        "spirit channeling",
        "霊媒",
        "霊術"
      ],
      unlocked_after_chapter: "ch2",
      keywords: [
        "口寄せ",
        "霊媒",
        "霊術",
        "channeling",
        "spirit channeling",
        "千尋を呼ぶ"
      ],
      category: "plot_twist",
      spoiler_level: "foreshadowing_hint",
      description: "綾里家に伝わる霊術。真宵が千尋の霊を呼び出すことができ、千尋は死後も真宵の口寄せを通じて成歩堂を助ける。"
    },
    {
      id: "ch3-defendant-will-powers",
      name: "荷星三郎",
      aliases: [
        "Will Powers",
        "トノサマン",
        "Steel Samurai"
      ],
      unlocked_after_chapter: "ch3",
      keywords: [
        "荷星",
        "荷星三郎",
        "Will Powers",
        "トノサマン",
        "被告"
      ],
      category: "other",
      spoiler_level: "foreshadowing_hint",
      description: "第3話の被告人。特撮番組「トノサマン」の主演俳優。"
    },
    {
      id: "ch3-victim-hammer",
      name: "衣袋武志",
      aliases: [
        "Jack Hammer",
        "トノサマンの元俳優",
        "Evil Magistrate"
      ],
      unlocked_after_chapter: "ch3",
      keywords: [
        "衣袋",
        "衣袋武志",
        "Jack Hammer",
        "Hammer",
        "被害者",
        "トノサマン",
        "元俳優"
      ],
      category: "plot_twist",
      spoiler_level: "direct_spoiler",
      description: "第3話の真の被害者。トノサマンの元主演俳優。過去の事故でキャリアを失い、復讐を図るが逆に殺された。"
    },
    {
      id: "ch3-culprit-dee-vasquez",
      name: "姫神サクラ",
      aliases: [
        "Dee Vasquez",
        "プロデューサー"
      ],
      unlocked_after_chapter: "ch3",
      keywords: [
        "姫神",
        "姫神サクラ",
        "Dee Vasquez",
        "プロデューサー",
        "マフィア",
        "犯人"
      ],
      category: "plot_twist",
      spoiler_level: "direct_spoiler",
      description: "第3話の犯人。トノサマンのプロデューサー。過去の事故の隠蔽のために衣袋武志を殺害した。"
    },
    {
      id: "ch3-past-accident",
      name: "5年前の事故（スタジオ）",
      aliases: [
        "the accident",
        "過去の事故",
        "Global Studios incident"
      ],
      unlocked_after_chapter: "ch3",
      keywords: [
        "5年前",
        "事故",
        "スタジオ",
        "グローバルスタジオ",
        "Global Studios"
      ],
      category: "foreshadowing",
      spoiler_level: "foreshadowing_hint",
      description: "第3話の核心。5年前に衣袋武志がスタジオで起こした事故が、今回の事件の動機につながる。"
    },
    {
      id: "ch4-culprit-von-karma",
      name: "狩魔豪",
      aliases: [
        "Manfred von Karma",
        "狩魔",
        "フォン・カルマ"
      ],
      unlocked_after_chapter: "ch4",
      keywords: [
        "狩魔",
        "狩魔豪",
        "Manfred von Karma",
        "von Karma",
        "フォン・カルマ",
        "犯人"
      ],
      category: "plot_twist",
      spoiler_level: "direct_spoiler",
      description: "第4話の犯人。完璧な有罪率を誇る伝説の検事。実はDL-6号事件の真犯人であり、御剣信を15年前に射殺していた。"
    },
    {
      id: "ch4-dl6-truth",
      name: "DL-6号事件の真相",
      aliases: [
        "DL-6",
        "DL6",
        "the DL-6 incident",
        "15年前の事件"
      ],
      unlocked_after_chapter: "ch4",
      keywords: [
        "DL-6",
        "DL6",
        "15年前",
        "真相",
        "御剣信",
        "Gregory Edgeworth",
        "エレベーター"
      ],
      category: "plot_twist",
      spoiler_level: "direct_spoiler",
      description: "15年前、エレベーターで起きた事件の真相。御剣信（Gregory Edgeworth）は狩魔豪に撃たれて死亡していた。狩魔は証拠隠滅のため御剣怜侍を犯人に仕立てようとした。"
    },
    {
      id: "ch4-victim-hammond",
      name: "生倉雪夫",
      aliases: [
        "Robert Hammond",
        "ハモンド"
      ],
      unlocked_after_chapter: "ch4",
      keywords: [
        "生倉",
        "生倉雪夫",
        "Robert Hammond",
        "Hammond",
        "悪徳弁護士",
        "湖"
      ],
      category: "plot_twist",
      spoiler_level: "direct_spoiler",
      description: "第4話の被害者。DL-6号事件に関わった弁護士。狩魔に射殺された。"
    },
    {
      id: "ch4-yanni-yogi",
      name: "灰根高太郎",
      aliases: [
        "Yanni Yogi"
      ],
      unlocked_after_chapter: "ch4",
      keywords: [
        "灰根",
        "灰根高太郎",
        "Yanni Yogi",
        "Yogi",
        "湖",
        "管理人"
      ],
      category: "plot_twist",
      spoiler_level: "direct_spoiler",
      description: "第4話に登場するDL-6号事件の関係者。"
    },
    {
      id: "ch4-edgeworth-father",
      name: "御剣信",
      aliases: [
        "Gregory Edgeworth",
        "御剣怜侍の父"
      ],
      unlocked_after_chapter: "ch4",
      keywords: [
        "御剣信",
        "Gregory Edgeworth",
        "怜侍の父",
        "弁護士",
        "射殺",
        "狩魔に殺された"
      ],
      category: "character_death",
      spoiler_level: "direct_spoiler",
      description: "御剣怜侍の父。狩魔豪と対立した腕利き弁護士だったが、DL-6号事件で狩魔に殺された。"
    },
    {
      id: "ch4-edgeworth-trauma",
      name: "御剣怜侍の過去のトラウマ",
      aliases: [
        "Edgeworth's trauma",
        "怜侍のトラウマ",
        "御剣の秘密"
      ],
      unlocked_after_chapter: "ch4",
      keywords: [
        "怜侍",
        "御剣",
        "トラウマ",
        "父を殺した",
        "地震",
        "銃"
      ],
      category: "plot_twist",
      spoiler_level: "direct_spoiler",
      description: "御剣怜侍は自分が父親を殺したと思い込んでいた。第4話の裁判でDL-6号事件の真相が明かされる。"
    },
    {
      id: "ch5-victim-goodman",
      name: "多田敷道夫",
      aliases: [
        "Bruce Goodman"
      ],
      unlocked_after_chapter: "ch5",
      keywords: [
        "多田敷",
        "多田敷道夫",
        "Bruce Goodman",
        "Goodman",
        "被害者",
        "刑事"
      ],
      category: "other",
      spoiler_level: "direct_spoiler",
      description: "第5話の被害者。SL-9号事件の主任捜査官だった刑事。"
    },
    {
      id: "ch5-defendant-lana",
      name: "宝月巴",
      aliases: [
        "Lana Skye",
        "宝月検事正",
        "チーフ検事"
      ],
      unlocked_after_chapter: "ch5",
      keywords: [
        "宝月巴",
        "宝月",
        "Lana Skye",
        "Lana",
        "被告",
        "検事正"
      ],
      category: "plot_twist",
      spoiler_level: "direct_spoiler",
      description: "第5話の被告人。宝月茜の姉で、検事正。殺人の容疑をかけられるが真相には深い事情がある。"
    },
    {
      id: "ch5-culprit-damon-gant",
      name: "巌徒海慈",
      aliases: [
        "Damon Gant",
        "Gant",
        "署長",
        "警察署長"
      ],
      unlocked_after_chapter: "ch5",
      keywords: [
        "巌徒",
        "巌徒海慈",
        "Damon Gant",
        "Gant",
        "署長",
        "警察署長",
        "犯人"
      ],
      category: "plot_twist",
      spoiler_level: "direct_spoiler",
      description: "第5話の犯人。警察署長でありながらSL-9号事件の証拠を隠蔽し、自らも殺人を犯した。"
    },
    {
      id: "ch5-sl9-truth",
      name: "SL-9号事件の真相",
      aliases: [
        "SL-9",
        "SL9",
        "the SL-9 incident",
        "2年前の事件"
      ],
      unlocked_after_chapter: "ch5",
      keywords: [
        "SL-9",
        "SL9",
        "2年前",
        "真相",
        "証拠改ざん"
      ],
      category: "plot_twist",
      spoiler_level: "direct_spoiler",
      description: "第5話の核心となる2年前の未解決事件。巌徒海慈が証拠を操作して犯人逮捕を主導したが、その過程に重大な不正があった。"
    },
    {
      id: "ch5-sl9-victim-neil",
      name: "罪門直斗",
      aliases: [
        "Neil Marshall"
      ],
      unlocked_after_chapter: "ch5",
      keywords: [
        "罪門直斗",
        "罪門",
        "Neil Marshall",
        "Neil",
        "SL-9",
        "殺された"
      ],
      category: "character_death",
      spoiler_level: "direct_spoiler",
      description: "SL-9号事件で死亡した人物。罪門恭介の関係者。"
    },
    {
      id: "ch5-joe-darke",
      name: "青影丈",
      aliases: [
        "Joe Darke",
        "連続殺人犯"
      ],
      unlocked_after_chapter: "ch5",
      keywords: [
        "青影",
        "青影丈",
        "Joe Darke",
        "Darke",
        "連続殺人犯",
        "SL-9"
      ],
      category: "plot_twist",
      spoiler_level: "direct_spoiler",
      description: "SL-9号事件で逮捕された連続殺人犯。第5話の事件の背景に深く関係する。"
    },
    {
      id: "ch5-ema-skye",
      name: "宝月茜",
      aliases: [
        "Ema Skye",
        "Ema"
      ],
      unlocked_after_chapter: "ch5",
      keywords: [
        "宝月茜",
        "宝月",
        "Ema Skye",
        "Ema",
        "SL-9",
        "科学捜査"
      ],
      category: "plot_twist",
      spoiler_level: "direct_spoiler",
      description: "科学捜査を志す少女。宝月巴の妹で、SL-9号事件の目撃者。第5話では成歩堂の助手を務める。"
    }
  ];
  const global_spoilers = [
    {
      id: "global-mia-alive-via-maya",
      name: "綾里千尋の口寄せによる活躍",
      aliases: [
        "Mia through Maya",
        "千尋の霊"
      ],
      keywords: [
        "千尋",
        "口寄せ",
        "Mia",
        "霊",
        "真宵から千尋",
        "spirit channeling"
      ],
      category: "plot_twist",
      spoiler_level: "foreshadowing_hint",
      description: "千尋は第2話で死亡するが、真宵の口寄せを通じて第3話・第4話でも成歩堂を助ける。「千尋が死んでいる」という事実と「口寄せで戻ってくる」という展開の両方がネタバレとなる。"
    },
    {
      id: "global-edgeworth-ally",
      name: "御剣怜侍の心境変化（敵から協力者へ）",
      aliases: [
        "Edgeworth becomes ally",
        "御剣の変化"
      ],
      keywords: [
        "御剣",
        "怜侍",
        "Edgeworth",
        "協力",
        "改心",
        "変わった"
      ],
      category: "plot_twist",
      spoiler_level: "foreshadowing_hint",
      description: "当初は敵対する検事だった御剣怜侍が、第4話の裁判を経て成歩堂を認め、心境が変化する。シリーズの核心的な関係性の変化。"
    },
    {
      id: "global-dl6-overarching",
      name: "DL-6号事件（シリーズ全体を貫く謎）",
      aliases: [
        "DL-6 incident",
        "DL-6事件",
        "15年前の謎"
      ],
      keywords: [
        "DL-6",
        "DL6",
        "15年前",
        "未解決事件",
        "御剣の過去"
      ],
      category: "foreshadowing",
      spoiler_level: "foreshadowing_hint",
      description: "第4話で解明される作品全体を貫く謎。「DL-6」という単語が言及された場合、第4話のネタバレに直結する可能性がある。"
    },
    {
      id: "global-von-karma-nemesis",
      name: "狩魔豪と御剣家の因縁",
      aliases: [
        "von Karma and Edgeworths",
        "狩魔と御剣の因縁"
      ],
      keywords: [
        "狩魔",
        "狩魔豪",
        "von Karma",
        "御剣",
        "因縁",
        "宿敵",
        "弟子"
      ],
      category: "plot_twist",
      spoiler_level: "foreshadowing_hint",
      description: "御剣怜侍は父を殺した狩魔豪に弟子として育てられた。この関係性は第4話のどんでん返しの根幹をなす。"
    },
    {
      id: "global-phoenix-maya-bond",
      name: "成歩堂と綾里真宵のパートナー関係",
      aliases: [
        "Phoenix and Maya partnership",
        "成歩堂と真宵"
      ],
      keywords: [
        "真宵",
        "Maya",
        "助手",
        "パートナー",
        "綾里事務所"
      ],
      category: "other",
      spoiler_level: "foreshadowing_hint",
      description: "千尋の死後、真宵が成歩堂の助手としてシリーズを通じて行動をともにする。「成歩堂が真宵を助手にした」こと自体が第2話以降のネタバレ。"
    }
  ];
  const aceAttorney1 = {
    $schema,
    id,
    title,
    title_aliases,
    progress_type,
    chapters,
    spoiler_entities,
    global_spoilers
  };
  const registry = {
    "ace-attorney-1": aceAttorney1
  };
  function getGame(id2) {
    return registry[id2];
  }
  function normalizeKana(text) {
    return text.normalize("NFKC").replace(/[\u3041-\u3096]/g, (ch) => String.fromCharCode(ch.charCodeAt(0) + 96)).toLowerCase();
  }
  const SPOILER_VERBS = [
    "死ぬ",
    "死んだ",
    "死亡",
    "殺される",
    "殺した",
    "殺す",
    "裏切る",
    "裏切り",
    "裏切った"
  ];
  const NORMALIZED_VERBS = SPOILER_VERBS.map(normalizeKana);
  function matchesSpoilerVerb(text) {
    const normalized = normalizeKana(text);
    for (let i = 0; i < NORMALIZED_VERBS.length; i++) {
      if (normalized.includes(NORMALIZED_VERBS[i])) return SPOILER_VERBS[i];
    }
    return null;
  }
  function getBlockedLevels(mode2) {
    switch (mode2) {
      case "strict":
        return ["direct_spoiler", "foreshadowing_hint", "gameplay_hint"];
      case "standard":
        return ["direct_spoiler", "foreshadowing_hint"];
      case "lenient":
        return ["direct_spoiler"];
      case "off":
        return [];
    }
  }
  function buildKeywordSet(gameId, filterMode, progress) {
    const game = getGame(gameId);
    if (!game) return /* @__PURE__ */ new Set();
    const blockedLevels = getBlockedLevels(filterMode);
    const keywords2 = /* @__PURE__ */ new Set();
    const chapters2 = game.chapters ?? [];
    const currentChapterIdx = (progress == null ? void 0 : progress.currentChapterId) ? chapters2.findIndex((c) => c.id === progress.currentChapterId) : -1;
    const shouldBlock = (entity) => {
      if (entity.spoiler_level && !blockedLevels.includes(entity.spoiler_level)) return false;
      if ((progress == null ? void 0 : progress.progressModel) === "chapter" && entity.unlocked_after_chapter && currentChapterIdx !== -1) {
        const unlockedIdx = chapters2.findIndex((c) => c.id === entity.unlocked_after_chapter);
        if (unlockedIdx !== -1 && currentChapterIdx > unlockedIdx) return false;
      }
      return true;
    };
    for (const entity of [...game.spoiler_entities, ...game.global_spoilers ?? []]) {
      if (shouldBlock(entity)) {
        for (const kw of entity.keywords) keywords2.add(kw);
      }
    }
    return keywords2;
  }
  function buildDescriptionPhraseSet(gameId) {
    const game = getGame(gameId);
    if (!game) return /* @__PURE__ */ new Set();
    const phrases = /* @__PURE__ */ new Set();
    const QUOTED_RE = /「([^」]+)」/g;
    const HAS_ALPHANUMERIC_RE = /[\d\w]/;
    const extractFromText = (text) => {
      if (!text) return;
      for (const match of text.matchAll(QUOTED_RE)) {
        const phrase = match[1];
        if (HAS_ALPHANUMERIC_RE.test(phrase)) {
          phrases.add(phrase);
        }
      }
    };
    for (const chapter of game.chapters ?? []) {
      extractFromText(chapter.description);
    }
    for (const entity of [...game.spoiler_entities, ...game.global_spoilers ?? []]) {
      extractFromText(entity.description);
    }
    return phrases;
  }
  function matchesKeyword(text, keywords2, descriptionPhrases) {
    const normalized = normalizeKana(text);
    if (normalized.includes("ネタバレ")) {
      return { reason: "spoiler_word" };
    }
    for (const phrase of descriptionPhrases) {
      if (normalized.includes(normalizeKana(phrase))) {
        return { reason: "description_phrase", phrase };
      }
    }
    const verb = matchesSpoilerVerb(text);
    if (verb !== null) {
      for (const kw of keywords2) {
        if (normalized.includes(normalizeKana(kw))) {
          return { reason: "keyword_with_verb", keyword: kw, verb };
        }
      }
    }
    return null;
  }
  function matchesKeywordForStage2(text, keywords2) {
    const normalized = normalizeKana(text);
    for (const kw of keywords2) {
      if (normalized.includes(normalizeKana(kw))) {
        return kw;
      }
    }
    return null;
  }
  function matchesCustomNGWord(text, words) {
    if (words.length === 0) return null;
    const normalized = normalizeKana(text);
    for (const entry of words) {
      if (!entry.enabled) continue;
      if (normalized.includes(normalizeKana(entry.word))) return entry.word;
    }
    return null;
  }
  function buildActiveGenreTemplates(selectedIds) {
    if (selectedIds.length === 0) return [];
    const all = getAllGenreTemplates();
    return all.filter((t) => selectedIds.includes(t.id));
  }
  function matchesGenreTemplate(text, templates) {
    if (templates.length === 0) return null;
    const normalized = normalizeKana(text);
    for (const template of templates) {
      for (const phrase of template.context_phrases) {
        if (normalized.includes(normalizeKana(phrase))) {
          return phrase;
        }
      }
      const verb = matchesSpoilerVerb(text);
      if (verb !== null) {
        for (const kw of template.keywords) {
          if (normalized.includes(normalizeKana(kw))) {
            return kw;
          }
        }
      }
    }
    return null;
  }
  function matchesGameplayHintForStage2(text, templates) {
    var _a;
    if (templates.length === 0) return null;
    const normalized = normalizeKana(text);
    for (const template of templates) {
      if (!((_a = template.stage2_phrases) == null ? void 0 : _a.length)) continue;
      for (const phrase of template.stage2_phrases) {
        if (normalized.includes(normalizeKana(phrase))) {
          return phrase;
        }
      }
    }
    return null;
  }
  function matchesGenreKeywordForStage2(text, templates) {
    if (templates.length === 0) return null;
    const normalized = normalizeKana(text);
    for (const template of templates) {
      for (const kw of template.keywords) {
        if (normalized.includes(normalizeKana(kw))) {
          return kw;
        }
      }
    }
    return null;
  }
  const ATTR_ORIGINAL = "data-fck-original";
  const ATTR_FILTERED$1 = "data-fck-filtered";
  const ATTR_HIDDEN_ROW = "data-fck-hidden-row";
  const ATTR_FALSE_POSITIVE = "data-fck-false-positive";
  const PLACEHOLDER = "⚠ ネタバレの可能性があるためフィルタされました（クリックで表示）";
  const MISREPORT_BTN_STYLE = [
    "margin-left:6px",
    "font-size:0.75em",
    "cursor:pointer",
    "opacity:0.65",
    "background:none",
    "border:1px solid currentColor",
    "border-radius:3px",
    "color:inherit",
    "padding:0 4px",
    "vertical-align:middle",
    "white-space:nowrap",
    "line-height:1.4"
  ].join(";");
  const toggleListeners = /* @__PURE__ */ new WeakMap();
  function filterMessageElement(el, displayMode, matchedKeyword, matchedContext, onReveal, onMisreport) {
    if (el.getAttribute(ATTR_FILTERED$1) === "true") return;
    const originalText = el.textContent ?? "";
    if (!originalText.trim()) return;
    el.setAttribute(ATTR_FILTERED$1, "true");
    if (matchedKeyword) {
      el.setAttribute("data-fck-matched-keyword", matchedKeyword);
    }
    if (matchedContext) {
      el.setAttribute("data-fck-matched-context", matchedContext);
    }
    if (displayMode === "hidden") {
      const row = el.closest("yt-live-chat-text-message-renderer") ?? el.closest("yt-live-chat-paid-message-renderer") ?? el.parentElement;
      if (row) {
        row.setAttribute(ATTR_HIDDEN_ROW, "true");
        row.style.display = "none";
      }
    } else {
      setupPlaceholderToggle(el, originalText, onReveal, onMisreport);
    }
  }
  function switchDisplayMode(el, nextMode, onReveal) {
    if (el.getAttribute(ATTR_FILTERED$1) !== "true") return;
    if (nextMode === "hidden") {
      abortToggleListener(el);
      const original = el.getAttribute(ATTR_ORIGINAL);
      if (original !== null) {
        el.textContent = original;
        el.removeAttribute(ATTR_ORIGINAL);
      }
      const row = el.closest("yt-live-chat-text-message-renderer") ?? el.closest("yt-live-chat-paid-message-renderer") ?? el.parentElement;
      if (row) {
        row.setAttribute(ATTR_HIDDEN_ROW, "true");
        row.style.display = "none";
      }
    } else {
      const originalText = el.textContent ?? "";
      setupPlaceholderToggle(el, originalText, onReveal, void 0);
      const hiddenRow = el.closest(`[${ATTR_HIDDEN_ROW}]`);
      if (hiddenRow) {
        hiddenRow.removeAttribute(ATTR_HIDDEN_ROW);
        hiddenRow.style.display = "";
      }
    }
  }
  function restoreMessageElement(el) {
    const filteredAttr = el.getAttribute(ATTR_FILTERED$1);
    if (filteredAttr !== "true" && filteredAttr !== "revealed") return;
    abortToggleListener(el);
    const hiddenRow = el.closest(`[${ATTR_HIDDEN_ROW}]`);
    if (hiddenRow) {
      hiddenRow.removeAttribute(ATTR_HIDDEN_ROW);
      hiddenRow.style.display = "";
    }
    const original = el.getAttribute(ATTR_ORIGINAL);
    if (original !== null) {
      el.textContent = original;
      el.removeAttribute(ATTR_ORIGINAL);
    }
    el.removeAttribute(ATTR_FILTERED$1);
  }
  const HIDE_BTN_STYLE = [
    "margin-left:6px",
    "font-size:0.75em",
    "cursor:pointer",
    "opacity:0.65",
    "background:none",
    "border:1px solid currentColor",
    "border-radius:3px",
    "color:inherit",
    "padding:0 4px",
    "vertical-align:middle",
    "white-space:nowrap",
    "line-height:1.4"
  ].join(";");
  function setupPlaceholderToggle(el, originalText, onReveal, onMisreport) {
    abortToggleListener(el);
    const ctrl = new AbortController();
    toggleListeners.set(el, ctrl);
    el.setAttribute(ATTR_ORIGINAL, originalText);
    el.textContent = "";
    const textSpan = document.createElement("span");
    textSpan.textContent = PLACEHOLDER;
    textSpan.style.cursor = "pointer";
    textSpan.style.opacity = "0.55";
    el.appendChild(textSpan);
    const hideBtn = document.createElement("button");
    hideBtn.style.cssText = HIDE_BTN_STYLE;
    hideBtn.textContent = "🔒 伏せる";
    hideBtn.style.display = "none";
    el.appendChild(hideBtn);
    let misreportBtn = null;
    let reported = el.getAttribute(ATTR_FALSE_POSITIVE) === "true";
    textSpan.addEventListener("click", (e) => {
      e.stopPropagation();
      if (el.getAttribute(ATTR_FILTERED$1) !== "true") return;
      textSpan.textContent = originalText;
      textSpan.style.cursor = "";
      textSpan.style.opacity = "";
      hideBtn.style.display = "";
      el.setAttribute(ATTR_FILTERED$1, "revealed");
      onReveal == null ? void 0 : onReveal();
      if (onMisreport) {
        if (!misreportBtn) {
          misreportBtn = createMisreportButton(reported, () => {
            reported = true;
            el.setAttribute(ATTR_FALSE_POSITIVE, "true");
            onMisreport();
          });
          el.appendChild(misreportBtn);
        } else {
          misreportBtn.style.display = "";
        }
      }
    }, { signal: ctrl.signal });
    hideBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      if (el.getAttribute(ATTR_FILTERED$1) !== "revealed") return;
      textSpan.textContent = PLACEHOLDER;
      textSpan.style.cursor = "pointer";
      textSpan.style.opacity = "0.55";
      hideBtn.style.display = "none";
      if (misreportBtn) misreportBtn.style.display = "none";
      el.setAttribute(ATTR_FILTERED$1, "true");
    }, { signal: ctrl.signal });
  }
  function createMisreportButton(alreadyReported, onReport) {
    const btn = document.createElement("button");
    btn.setAttribute("data-fck-misreport", "true");
    btn.style.cssText = MISREPORT_BTN_STYLE;
    if (alreadyReported) {
      btn.textContent = "✓ 報告済み";
      btn.disabled = true;
      btn.style.cursor = "default";
      btn.style.opacity = "0.45";
    } else {
      btn.textContent = "❌ 誤判定";
      btn.addEventListener("click", (e) => {
        e.stopPropagation();
        btn.textContent = "✓ 報告済み";
        btn.disabled = true;
        btn.style.cursor = "default";
        btn.style.opacity = "0.45";
        onReport();
      }, { once: true });
    }
    return btn;
  }
  function abortToggleListener(el) {
    var _a;
    (_a = toggleListeners.get(el)) == null ? void 0 : _a.abort();
    toggleListeners.delete(el);
  }
  const DEFAULT_SETTINGS = {
    enabled: true,
    gameId: "ace-attorney-1",
    progressByGame: {},
    filterMode: "standard",
    displayMode: "placeholder",
    proxyUrl: "https://fresh-chat-keeper-proxy.playnicelab.workers.dev",
    customNgWords: [],
    selectedGenreTemplates: []
  };
  const STORAGE_KEY = "fck_settings";
  const ANON_TOKEN_KEY = "fck_anon_token";
  const FILTER_COUNT_KEY = "fck_filter_count";
  const STAGE2_USAGE_KEY = "fck_stage2_usage";
  const MISREPORT_KEY = "fck_misreports";
  const MISREPORT_MAX_COUNT = 100;
  async function saveMisreport(entry) {
    const result = await chrome.storage.local.get(MISREPORT_KEY);
    const entries = result[MISREPORT_KEY] ?? [];
    entries.push(entry);
    if (entries.length > MISREPORT_MAX_COUNT) {
      entries.splice(0, entries.length - MISREPORT_MAX_COUNT);
    }
    await chrome.storage.local.set({ [MISREPORT_KEY]: entries });
  }
  const STAGE2_MONTHLY_LIMIT = 1e3;
  function getCurrentMonth() {
    const now = /* @__PURE__ */ new Date();
    return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`;
  }
  async function getStage2Usage() {
    const result = await chrome.storage.local.get(STAGE2_USAGE_KEY);
    const stored = result[STAGE2_USAGE_KEY];
    const currentMonth = getCurrentMonth();
    if (!stored || stored.month !== currentMonth) {
      return { month: currentMonth, messageCount: 0, apiCallCount: 0 };
    }
    return {
      month: stored.month,
      messageCount: stored.messageCount ?? 0,
      apiCallCount: stored.apiCallCount ?? 0
    };
  }
  async function incrementStage2Usage(messages) {
    const usage = await getStage2Usage();
    const updated = {
      month: usage.month,
      messageCount: usage.messageCount + messages,
      apiCallCount: usage.apiCallCount + 1
    };
    await chrome.storage.local.set({ [STAGE2_USAGE_KEY]: updated });
    return updated;
  }
  async function getOrCreateAnonToken() {
    const result = await chrome.storage.local.get(ANON_TOKEN_KEY);
    const existing = result[ANON_TOKEN_KEY];
    if (existing) return existing;
    const token = crypto.randomUUID();
    await chrome.storage.local.set({ [ANON_TOKEN_KEY]: token });
    console.log("[FreshChatKeeper] 匿名トークンを生成しました:", token.slice(0, 8) + "...");
    return token;
  }
  const SETTINGS_V1_BACKUP_KEY = "fck_settings_v1_backup";
  async function loadSettings() {
    const result = await chrome.storage.local.get(STORAGE_KEY);
    const raw = result[STORAGE_KEY];
    if (raw === void 0 || raw === null) {
      return { ...DEFAULT_SETTINGS };
    }
    if (isStoredV2(raw)) {
      return stripVersion(raw);
    }
    return await migrateLegacyToV2(raw);
  }
  function isStoredV2(raw) {
    return typeof raw === "object" && raw !== null && !Array.isArray(raw) && raw.version === 2;
  }
  function stripVersion(raw) {
    const { version: _ignore, ...rest } = raw;
    return { ...DEFAULT_SETTINGS, ...rest };
  }
  async function migrateLegacyToV2(raw) {
    const partial = typeof raw === "object" && raw !== null && !Array.isArray(raw) ? raw : {};
    const merged = { ...DEFAULT_SETTINGS, ...partial };
    const stored = { ...merged, version: 2 };
    const backupExisting = await chrome.storage.local.get(SETTINGS_V1_BACKUP_KEY);
    const updates = { [STORAGE_KEY]: stored };
    if (backupExisting[SETTINGS_V1_BACKUP_KEY] === void 0) {
      updates[SETTINGS_V1_BACKUP_KEY] = raw;
    }
    await chrome.storage.local.set(updates);
    console.log(
      "[FreshChatKeeper] 設定スキーマを v2 にマイグレーションしました（旧データは fck_settings_v1_backup に保存）"
    );
    return merged;
  }
  const LLM_CATEGORY_SET = /* @__PURE__ */ new Set([
    "direct_spoiler",
    "foreshadowing_hint",
    "gameplay_hint",
    "safe"
  ]);
  function verdictFromCache(entry, filterMode) {
    const { spoilerCategory } = entry;
    if (spoilerCategory === null) {
      return filterMode === "lenient" ? "allow" : "block";
    }
    switch (spoilerCategory) {
      case "direct_spoiler":
        return "block";
      case "foreshadowing_hint":
        return filterMode === "lenient" ? "allow" : "block";
      case "gameplay_hint":
        return filterMode === "strict" ? "block" : "allow";
      case "safe":
        return "allow";
    }
  }
  function parseSpoilerCategory(raw) {
    if (raw == null) return null;
    return LLM_CATEGORY_SET.has(raw) ? raw : null;
  }
  const JUDGE_CACHE_KEY = "fck_judge_cache";
  let _cache = {};
  let _cacheLoaded = false;
  async function initStage2Cache() {
    if (_cacheLoaded) return;
    const result = await chrome.storage.local.get(JUDGE_CACHE_KEY);
    _cache = result[JUDGE_CACHE_KEY] ?? {};
    _cacheLoaded = true;
  }
  function getCachedVerdict(cacheKey) {
    return _cache[cacheKey] ?? null;
  }
  async function saveJudgeCacheEntry(cacheKey, entry) {
    _cache[cacheKey] = entry;
    await chrome.storage.local.set({ [JUDGE_CACHE_KEY]: _cache });
  }
  function buildStage2CacheKey(gameId, progress, text) {
    let progressKey = "none";
    if ((progress == null ? void 0 : progress.progressModel) === "chapter") {
      progressKey = progress.currentChapterId ?? "none";
    } else if ((progress == null ? void 0 : progress.progressModel) === "event") {
      progressKey = [...progress.completedEventIds ?? []].sort().join(",") || "none";
    }
    return `${gameId}|${progressKey}|${text}`;
  }
  function createChromeTransport(proxyUrl, token) {
    return {
      async sendJudgeRequest(payload) {
        const res = await fetch(`${proxyUrl}/api/judge`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "x-fck-token": token
          },
          body: JSON.stringify(payload)
        });
        if (!res.ok) {
          throw new Error(`Stage 2 proxy error: HTTP ${res.status}`);
        }
        return await res.json();
      }
    };
  }
  async function sendStage2Batch(batch, settings, token, onResult, videoTitle) {
    if (batch.length === 0) return true;
    const transport = createChromeTransport(settings.proxyUrl, token);
    const payload = buildJudgeRequestPayload(batch, settings, videoTitle);
    let response;
    try {
      response = await transport.sendJudgeRequest(payload);
    } catch (err) {
      console.error(
        `[FreshChatKeeper] Stage 2エラー: ${err instanceof Error ? err.message : String(err)}`
      );
      return false;
    }
    for (const result of response.results) {
      const idx = parseInt(result.messageId, 10);
      const candidate = batch[idx];
      if (!candidate) continue;
      const spoilerCategory = parseSpoilerCategory(result.spoilerCategory);
      const entry = {
        spoilerCategory,
        ...result.confidence !== void 0 ? { confidence: result.confidence } : {}
      };
      await saveJudgeCacheEntry(candidate.cacheKey, entry);
      onResult(candidate, entry);
    }
    return true;
  }
  function buildJudgeRequestPayload(batch, settings, videoTitle) {
    const context = buildJudgmentContext(settings, videoTitle);
    return {
      messages: batch.map((c, i) => ({ id: String(i), text: c.text })),
      context: {
        game: context.game,
        settings: context.settings
      },
      tier: "free"
    };
  }
  function buildJudgmentContext(settings, videoTitle) {
    const isKBGame = settings.gameId !== "none" && settings.gameId !== "other";
    const game = buildGameContext(settings, isKBGame, videoTitle);
    const filterSettings = {
      version: 2,
      enabled: settings.enabled,
      displayMode: settings.displayMode,
      filterMode: "archive",
      // v2 の filterMode は archive/live。既存 chrome-ext には対応情報なし → archive 既定
      categories: {
        spoiler: {
          enabled: true,
          strength: legacyFilterModeToStrength(settings.filterMode)
        }
      },
      customBlockWords: settings.customNgWords.filter((w) => w.enabled).map((w) => w.word),
      userTier: "free",
      ...game ? { gameContext: game } : {}
    };
    return { settings: filterSettings, ...game ? { game } : {} };
  }
  function buildGameContext(settings, isKBGame, videoTitle) {
    const selected = settings.selectedGenreTemplates ?? [];
    if (!isKBGame && selected.length === 0 && !videoTitle) return void 0;
    const progress = isKBGame ? settings.progressByGame[settings.gameId] : void 0;
    let progressType = "none";
    let currentChapter;
    let completedEvents;
    if ((progress == null ? void 0 : progress.progressModel) === "chapter" && progress.currentChapterId) {
      progressType = "chapter";
      currentChapter = progress.currentChapterId;
    } else if ((progress == null ? void 0 : progress.progressModel) === "event" && progress.completedEventIds) {
      progressType = "event";
      completedEvents = progress.completedEventIds;
    }
    const genreTemplate = buildGenreTemplateField(selected);
    return {
      ...isKBGame ? { gameId: settings.gameId } : {},
      ...videoTitle ? { gameTitle: videoTitle } : {},
      progressType,
      ...currentChapter ? { currentChapter } : {},
      ...completedEvents ? { completedEvents } : {},
      ...genreTemplate ? { genreTemplate } : {}
    };
  }
  function buildGenreTemplateField(selectedIds) {
    if (selectedIds.length === 0) return void 0;
    if (selectedIds.length === 1) return selectedIds[0];
    const all = getAllGenreTemplates();
    return selectedIds.map((id2) => {
      var _a;
      return ((_a = all.find((t) => t.id === id2)) == null ? void 0 : _a.name) ?? id2;
    }).join("・");
  }
  function legacyFilterModeToStrength(mode2) {
    switch (mode2) {
      case "lenient":
        return "loose";
      case "strict":
        return "strict";
      case "standard":
      case "off":
        return "standard";
    }
  }
  const ITEMS_SELECTOR = "#items";
  const MSG_TEXT_SELECTOR = "#message";
  const FILTERED_SELECTOR = "[data-fck-filtered]";
  const ATTR_FILTERED = "data-fck-filtered";
  const ATTR_PENDING = "data-fck-pending";
  const ATTR_PENDING_ROW = "data-fck-pending-row";
  const STAGE2_PENDING_TIMEOUT_MS = 5e3;
  function isContextValid() {
    var _a;
    try {
      return !!((_a = chrome.runtime) == null ? void 0 : _a.id);
    } catch {
      return false;
    }
  }
  function shutdownOnInvalidContext() {
    console.log("[FreshChatKeeper] 拡張コンテキストが無効になりました。監視を停止します。");
    itemsObserver == null ? void 0 : itemsObserver.disconnect();
    itemsObserver = null;
    clearStage2Queue();
  }
  let currentSettings = null;
  let currentKeywords = /* @__PURE__ */ new Set();
  let currentDescriptionPhrases = /* @__PURE__ */ new Set();
  let currentGenreTemplates = [];
  let currentVideoTitle = "";
  let itemsContainerRef = null;
  let itemsObserver = null;
  let isUpdatingDisplayMode = false;
  const revealedTexts = /* @__PURE__ */ new Set();
  let stage2Queue = [];
  const stage2PendingTimeouts = /* @__PURE__ */ new Map();
  let isDraining = false;
  let drainDebounceTimer = null;
  let anonToken = "";
  function startArchiveMode(mode2 = "archive") {
    console.log(`[FreshChatKeeper] ${mode2 === "live" ? "ライブモード" : "アーカイブモード"}で起動しました`);
    currentVideoTitle = getVideoTitle();
    chrome.storage.local.set({ [FILTER_COUNT_KEY]: 0 });
    Promise.all([initStage2Cache(), getOrCreateAnonToken()]).then(([, token]) => {
      anonToken = token;
    });
    loadSettings().then((settings) => {
      currentSettings = settings;
      currentKeywords = buildKeywordsFromSettings(settings);
      chrome.storage.onChanged.addListener((changes, area) => {
        if (area !== "local" || !changes[STORAGE_KEY]) return;
        const prev = changes[STORAGE_KEY].oldValue;
        const next = changes[STORAGE_KEY].newValue;
        const displayModeChanged = (prev == null ? void 0 : prev.displayMode) !== next.displayMode;
        const onlyDisplayModeChanged = displayModeChanged && (prev == null ? void 0 : prev.enabled) === next.enabled && (prev == null ? void 0 : prev.gameId) === next.gameId && (prev == null ? void 0 : prev.filterMode) === next.filterMode && JSON.stringify(prev == null ? void 0 : prev.progressByGame) === JSON.stringify(next.progressByGame) && JSON.stringify(prev == null ? void 0 : prev.customNgWords) === JSON.stringify(next.customNgWords) && JSON.stringify(prev == null ? void 0 : prev.selectedGenreTemplates) === JSON.stringify(next.selectedGenreTemplates);
        currentSettings = next;
        currentKeywords = buildKeywordsFromSettings(next);
        if (!itemsContainerRef) return;
        if (onlyDisplayModeChanged) {
          isUpdatingDisplayMode = true;
          itemsContainerRef.querySelectorAll('[data-fck-filtered="true"]').forEach((el) => {
            switchDisplayMode(el, next.displayMode, () => {
              var _a;
              const text = el.getAttribute("data-fck-original") ?? ((_a = el.textContent) == null ? void 0 : _a.trim()) ?? "";
              if (text) revealedTexts.add(text);
            });
          });
          isUpdatingDisplayMode = false;
        } else {
          clearStage2Queue();
          reprocessAll(itemsContainerRef);
        }
      });
      if (settings.enabled) {
        waitForItemsContainer();
      }
    });
  }
  function buildKeywordsFromSettings(settings) {
    const progress = settings.progressByGame[settings.gameId];
    currentDescriptionPhrases = buildDescriptionPhraseSet(settings.gameId);
    currentGenreTemplates = buildActiveGenreTemplates(settings.selectedGenreTemplates ?? []);
    return buildKeywordSet(settings.gameId, settings.filterMode, progress);
  }
  function pauseObserver() {
    itemsObserver == null ? void 0 : itemsObserver.disconnect();
  }
  function resumeObserver() {
    if (itemsObserver && itemsContainerRef) {
      itemsObserver.observe(itemsContainerRef, { childList: true });
    }
  }
  function waitForItemsContainer() {
    const existing = document.querySelector(ITEMS_SELECTOR);
    if (existing) {
      observeItems(existing);
      return;
    }
    const observer = new MutationObserver(() => {
      const el = document.querySelector(ITEMS_SELECTOR);
      if (el) {
        observer.disconnect();
        observeItems(el);
      }
    });
    observer.observe(document.documentElement, {
      childList: true,
      subtree: true
    });
  }
  function observeItems(itemsContainer) {
    itemsContainerRef = itemsContainer;
    itemsContainer.querySelectorAll(MSG_TEXT_SELECTOR).forEach((el) => {
      processMessage(el);
    });
    itemsObserver = new MutationObserver((mutations) => {
      if (isUpdatingDisplayMode) return;
      const hasRemovals = mutations.some((m) => m.removedNodes.length > 0);
      if (hasRemovals) {
        revealedTexts.clear();
        clearStage2Queue();
      }
      for (const mutation of mutations) {
        for (const node of mutation.addedNodes) {
          if (!(node instanceof Element)) continue;
          const msgEl = node.matches(MSG_TEXT_SELECTOR) ? node : node.querySelector(MSG_TEXT_SELECTOR);
          if (msgEl) processMessage(msgEl);
        }
      }
    });
    itemsObserver.observe(itemsContainer, { childList: true });
  }
  function reprocessAll(itemsContainer) {
    isUpdatingDisplayMode = true;
    pauseObserver();
    itemsContainer.querySelectorAll(FILTERED_SELECTOR).forEach((el) => {
      restoreMessageElement(el);
    });
    if (currentSettings == null ? void 0 : currentSettings.enabled) {
      itemsContainer.querySelectorAll(MSG_TEXT_SELECTOR).forEach((el) => {
        processMessage(el);
      });
    }
    resumeObserver();
    isUpdatingDisplayMode = false;
  }
  function processMessage(el) {
    var _a, _b;
    if (!isContextValid()) {
      shutdownOnInvalidContext();
      return;
    }
    if (!(currentSettings == null ? void 0 : currentSettings.enabled)) return;
    if (el.getAttribute(ATTR_FALSE_POSITIVE) === "true") return;
    if (el.hasAttribute(ATTR_FILTERED)) {
      const storedOriginal = el.getAttribute("data-fck-original");
      const isStale = el.getAttribute(ATTR_FILTERED) === "revealed" && !revealedTexts.has(storedOriginal ?? "");
      const isTrueFiltered = el.getAttribute(ATTR_FILTERED) === "true";
      if (!isStale && isTrueFiltered) return;
      el.removeAttribute(ATTR_FILTERED);
      el.removeAttribute("data-fck-original");
      el.removeAttribute("data-fck-matched-keyword");
      el.removeAttribute("data-fck-matched-context");
      el.style.cursor = "";
      if (el.hasAttribute(ATTR_PENDING)) showPendingElement(el);
    }
    if (el.getAttribute(ATTR_PENDING) === "true") {
      const currentText = ((_a = el.textContent) == null ? void 0 : _a.trim()) ?? "";
      const isStillQueued = stage2Queue.some((c) => c.el.deref() === el && c.text === currentText);
      if (isStillQueued) return;
      showPendingElement(el);
    }
    const text = ((_b = el.textContent) == null ? void 0 : _b.trim()) ?? "";
    if (!text) return;
    if (revealedTexts.has(text)) return;
    const customNgWords = currentSettings.customNgWords ?? [];
    const matchedNgWord = matchesCustomNGWord(text, customNgWords);
    if (matchedNgWord !== null) {
      applyFilter(el, text, matchedNgWord);
      return;
    }
    const matchedGenre = matchesGenreTemplate(text, currentGenreTemplates);
    if (matchedGenre !== null) {
      applyFilter(el, text, matchedGenre);
      return;
    }
    const matchResult = matchesKeyword(text, currentKeywords, currentDescriptionPhrases);
    if (matchResult !== null) {
      applyFilter(el, text, matchResult.keyword, matchResult.verb ?? matchResult.phrase);
      return;
    }
    const stage2keyword = matchesKeywordForStage2(text, currentKeywords);
    if (!stage2keyword) {
      if (currentSettings.gameId !== "none" && currentGenreTemplates.length > 0) {
        const hintPhrase = matchesGameplayHintForStage2(text, currentGenreTemplates);
        if (hintPhrase !== null) {
          const progress2 = currentSettings.progressByGame[currentSettings.gameId];
          const cacheKey2 = buildStage2CacheKey(currentSettings.gameId, progress2, text);
          const cached2 = getCachedVerdict(cacheKey2);
          if (cached2 !== null) {
            applyStage2Verdict({ text, el: new WeakRef(el), cacheKey: cacheKey2, matchedKeyword: hintPhrase }, cached2);
            return;
          }
          hidePendingElement(el, cacheKey2);
          stage2Queue.push({ text, el: new WeakRef(el), cacheKey: cacheKey2, matchedKeyword: hintPhrase });
          scheduleDrain();
          return;
        }
      }
      if (currentSettings.gameId === "other" && currentGenreTemplates.length > 0) {
        const genreKeyword = matchesGenreKeywordForStage2(text, currentGenreTemplates);
        if (genreKeyword) {
          const cacheKey2 = buildStage2CacheKey("other", void 0, text);
          const cached2 = getCachedVerdict(cacheKey2);
          if (cached2 !== null) {
            applyStage2Verdict({ text, el: new WeakRef(el), cacheKey: cacheKey2, matchedKeyword: genreKeyword }, cached2);
            return;
          }
          hidePendingElement(el, cacheKey2);
          stage2Queue.push({ text, el: new WeakRef(el), cacheKey: cacheKey2, matchedKeyword: genreKeyword });
          scheduleDrain();
        }
      }
      return;
    }
    const progress = currentSettings.progressByGame[currentSettings.gameId];
    const cacheKey = buildStage2CacheKey(currentSettings.gameId, progress, text);
    const cached = getCachedVerdict(cacheKey);
    if (cached !== null) {
      applyStage2Verdict({ text, el: new WeakRef(el), cacheKey, matchedKeyword: stage2keyword }, cached);
      return;
    }
    hidePendingElement(el, cacheKey);
    stage2Queue.push({ text, el: new WeakRef(el), cacheKey, matchedKeyword: stage2keyword });
    scheduleDrain();
  }
  function clearStage2Queue() {
    for (const timer of stage2PendingTimeouts.values()) clearTimeout(timer);
    stage2PendingTimeouts.clear();
    for (const candidate of stage2Queue) {
      const el = candidate.el.deref();
      if (el) showPendingElement(el);
    }
    stage2Queue = [];
  }
  function scheduleDrain() {
    if (drainDebounceTimer !== null) return;
    drainDebounceTimer = setTimeout(() => {
      drainDebounceTimer = null;
      drainStage2Queue();
    }, 200);
  }
  async function drainStage2Queue() {
    if (isDraining || !(currentSettings == null ? void 0 : currentSettings.enabled) || !anonToken) return;
    if (stage2Queue.length === 0) return;
    isDraining = true;
    try {
      while (stage2Queue.length > 0) {
        if (!isContextValid()) {
          shutdownOnInvalidContext();
          break;
        }
        if (!(currentSettings == null ? void 0 : currentSettings.enabled)) break;
        const usage = await getStage2Usage();
        if (usage.messageCount >= STAGE2_MONTHLY_LIMIT) {
          console.log(`[FreshChatKeeper] Stage 2月間上限(${STAGE2_MONTHLY_LIMIT}回)に達しました。Stage 1のみで動作を継続します。`);
          stage2Queue = [];
          break;
        }
        const batch = stage2Queue.splice(0, 5);
        if (batch.length === 0) break;
        const success = await sendStage2Batch(batch, currentSettings, anonToken, applyStage2Verdict, currentVideoTitle);
        if (success) await incrementStage2Usage(batch.length);
        if (stage2Queue.length > 0) {
          await sleep(1e3);
        }
      }
    } finally {
      isDraining = false;
      if (stage2Queue.length > 0) {
        scheduleDrain();
      }
    }
  }
  function applyStage2Verdict(candidate, entry) {
    var _a;
    if (!currentSettings) return;
    const timer = stage2PendingTimeouts.get(candidate.cacheKey);
    if (timer !== void 0) {
      clearTimeout(timer);
      stage2PendingTimeouts.delete(candidate.cacheKey);
    }
    const el = candidate.el.deref();
    if (el) showPendingElement(el);
    const verdict = verdictFromCache(entry, currentSettings.filterMode);
    if (verdict === "allow") return;
    if (!el) return;
    if (!currentSettings.enabled) return;
    if (el.getAttribute(ATTR_FALSE_POSITIVE) === "true") return;
    if (el.hasAttribute(ATTR_FILTERED)) return;
    if (((_a = el.textContent) == null ? void 0 : _a.trim()) !== candidate.text) return;
    if (revealedTexts.has(candidate.text)) return;
    applyFilter(el, candidate.text, candidate.matchedKeyword, void 0, entry.spoilerCategory);
  }
  function applyFilter(el, text, matchedKeyword, matchedContext, spoilerCategory) {
    if (!currentSettings) return;
    const settings = currentSettings;
    const onMisreport = () => {
      const entry = {
        text,
        spoilerCategory: spoilerCategory ?? null,
        gameId: settings.gameId,
        progress: settings.progressByGame[settings.gameId] ?? null,
        filterMode: settings.filterMode,
        timestamp: (/* @__PURE__ */ new Date()).toISOString()
      };
      saveMisreport(entry);
    };
    filterMessageElement(
      el,
      settings.displayMode,
      matchedKeyword,
      matchedContext,
      () => {
        revealedTexts.add(text);
      },
      onMisreport
    );
    try {
      chrome.storage.local.get(FILTER_COUNT_KEY, (result) => {
        const prev = result[FILTER_COUNT_KEY] ?? 0;
        chrome.storage.local.set({ [FILTER_COUNT_KEY]: prev + 1 });
      });
    } catch {
      shutdownOnInvalidContext();
    }
  }
  function getVideoTitle() {
    var _a, _b;
    try {
      const title2 = ((_b = (_a = window.parent) == null ? void 0 : _a.document) == null ? void 0 : _b.title) ?? "";
      return title2.replace(/\s*[-–]\s*YouTube\s*$/, "").trim();
    } catch {
      return "";
    }
  }
  function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }
  function hidePendingElement(el, cacheKey) {
    el.setAttribute(ATTR_PENDING, "true");
    const row = el.closest("yt-live-chat-text-message-renderer") ?? el.closest("yt-live-chat-paid-message-renderer") ?? el.parentElement;
    if (row) {
      row.setAttribute(ATTR_PENDING_ROW, "true");
      row.style.display = "none";
    }
    const timer = setTimeout(() => {
      stage2PendingTimeouts.delete(cacheKey);
      showPendingElement(el);
    }, STAGE2_PENDING_TIMEOUT_MS);
    stage2PendingTimeouts.set(cacheKey, timer);
  }
  function showPendingElement(el) {
    el.removeAttribute(ATTR_PENDING);
    const row = el.closest(`[${ATTR_PENDING_ROW}]`);
    if (row) {
      row.removeAttribute(ATTR_PENDING_ROW);
      row.style.display = "";
    }
  }
  const mode = detectMode();
  switch (mode) {
    case "archive":
      startArchiveMode("archive");
      break;
    case "live":
      startArchiveMode("live");
      break;
  }
})();
